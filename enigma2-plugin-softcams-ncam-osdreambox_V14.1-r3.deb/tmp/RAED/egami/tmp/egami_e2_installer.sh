#!/bin/sh

python /usr/lib/enigma2/python/hiroshima.py
