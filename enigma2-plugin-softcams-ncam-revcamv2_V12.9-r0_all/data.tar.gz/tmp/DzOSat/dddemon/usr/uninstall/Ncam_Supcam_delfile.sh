#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"
# Type: Cam

killall -9 ncam 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/ncam
rm -rf /usr/script/Ncam_Supcam_cam.sh
rm -rf /usr/uninstall/Ncam_Supcam_delfile.sh

exit 0
