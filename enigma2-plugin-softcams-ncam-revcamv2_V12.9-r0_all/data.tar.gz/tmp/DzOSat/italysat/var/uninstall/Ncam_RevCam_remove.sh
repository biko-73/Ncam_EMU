#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"

/var/emuscript/Ncam_RevCam_em.sh stop

rm -rf /var/bin/ncam
rm -rf /var/emuscript/Ncam_RevCam_em.sh
rm -rf /var/uninstall/Ncam_RevCam_remove.sh

exit 0
