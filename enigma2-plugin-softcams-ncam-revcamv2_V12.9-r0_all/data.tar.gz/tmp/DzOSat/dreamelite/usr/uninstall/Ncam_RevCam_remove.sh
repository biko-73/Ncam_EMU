#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"

killall -9 ncam
sleep 5
rm -rf /usr/bin/ncam
rm -rf /usr/script/Ncam_Supcam_em.sh
rm -rf /usr/uninstall/Ncam_Supcam_remove.sh

exit 0
