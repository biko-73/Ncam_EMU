#### "*******************************************"
#### "*          << RAED - fairbird >>          *"
#### "*******************************************"
#### "****************************************************************"             
#### "*Read more: https://www.tunisia-sat.com/forums/threads/3539021/*"
#### "****************************************************************"
#################################################################################
#                             ncam.fs == CCcam.cfg                              #
#                                                                               #
# C: <hostname> <port> <username> <password> <wantemus>                         #
# N: <ip> <port> <username> <pass> <des(14byte)> <nr_of_hops_away (default: 1)> #
# R: <ip> <port> <ca4> <id6> <nr_of_hops_away (default: 1)>                     #
# L: <ip> <port> <username> <pass> <ca4> <id6> <nr_of_hops_away (default: 1)>   #
#                                                                               #
# http://<url>/... # (C, N: load rows from the URL using libcurl ...)           #
#                                                                               #
# Line Enable/Disable =? (" # ")                                                #
#################################################################################
#

### preset servers #########
#     SERVER0 to SERVER9  #
############################

SERVER0

### Need to be fix
#https://cccamx.com/free-cccam
#http://server.satunivers.tv
#https://www.cccambird.com/freecccam.php
#https://www.cccamprime.com/cccam48h.php
#http://cccameurop.com/freetest.php
#https://cccamiptv.co/free-cccam/


#Thisis to test the server line
#https://testcline.com
