#!/bin/sh
########################################
######      Edited by RAED        ######
########################################

kill 2>/dev/null `cat 2>/dev/null /tmp/ncam.pid`
killall -9 ncam 2>/dev/null


rm -rf /usr/bin/ncam
rm -rf /usr/ppteam/ncam.pp
rm -rf /usr/ppuninstall/ncam_delfile.pp


exit 0

