#!/bin/sh
####################################
# Created By RAED 22-02-2021 Boxes #
#   Update By RAED 14-02-2025      #
####################################
#### Tmp work director 
TMPDIR='/tmp/RAED'
BINPATH='/tmp/RAED/ncam'
ARMBIN='/tmp/RAED/ARM/ncam'
MIPSBIN='/tmp/RAED/MIPS/ncam'
AARCH64BIN='/tmp/RAED/AARCH64/ncam'
#### Path of opkg files
STATUS='/var/lib/dpkg/status'
INFO='/var/lib/dpkg/info'
#### checking your device path
CHECK='/tmp/check'
# Path of Config Files
CONFIGPATH='/etc/tuxbox/config'
# Path of Config File in Boxes Avilable
CONFIGcookies='/etc/tuxbox/config/ncam.cookies'
CONFIGccache='/etc/tuxbox/config/ncam.ccache'
CONFIGconf='/etc/tuxbox/config/ncam.conf'
CONFIGdvbapi='/etc/tuxbox/config/ncam.dvbapi'
CONFIGprovid='/etc/tuxbox/config/ncam.provid'
CONFIGserver='/etc/tuxbox/config/ncam.server'
CONFIGservices='/etc/tuxbox/config/ncam.services'
CONFIGsrvid2='/etc/tuxbox/config/ncam.srvid2'
CONFIGuser='/etc/tuxbox/config/ncam.user'
AUTOROLL='/etc/tuxbox/config/AutoRoll.Key'
SOFTCAM='/etc/tuxbox/config/SoftCam.Key'
CONSTANT='/etc/tuxbox/config/constant.cw'
CCCAMCFG='/etc/tuxbox/config/CCcam.cfg'
NCAMFS='/etc/tuxbox/config/ncam.fs'
# Path of Config File in Tmp Folder
CONFIGcookiestmp='/tmp/RAED/etc/tuxbox/config/ncam.cookies'
CONFIGccachetmp='/tmp/RAED/etc/tuxbox/config/ncam.ccache'
CONFIGconftmp='/tmp/RAED/etc/tuxbox/config/ncam.conf'
CONFIGdvbapitmp='/tmp/RAED/etc/tuxbox/config/ncam.dvbapi'
CONFIGprovidtmp='/tmp/RAED/etc/tuxbox/config/ncam.provid'
CONFIGservertmp='/tmp/RAED/etc/tuxbox/config/ncam.server'
CONFIGservicestmp='/tmp/RAED/etc/tuxbox/config/ncam.services'
CONFIGsrvid2tmp='/tmp/RAED/etc/tuxbox/config/ncam.srvid2'
CONFIGusertmp='/tmp/RAED/etc/tuxbox/config/ncam.user'
AUTOROLLtmp='/tmp/RAED/etc/tuxbox/config/AutoRoll.Key'
SOFTCAMtmp='/tmp/RAED/etc/tuxbox/config/SoftCam.Key'
CONSTANTtmp='/tmp/RAED/etc/tuxbox/config/constant.cw'
CONFIGCCCamCFGtmp='/tmp/RAED/etc/tuxbox/config/CCcam.cfg'
NCAMFStmp='/tmp/RAED/etc/tuxbox/config/ncam.fs'
### find image name type
GP3='/usr/lib/enigma2/python/Plugins/Bp/geminimain'
GP4='/usr/lib/enigma2/python/Plugins/GP4/geminilocale/plugin.pyo'
VTI='/usr/lib/enigma2/python/Plugins/SystemPlugins/VTIPanel'
TSIMAGE='/usr/lib/enigma2/python/Plugins/TSimage'
MERLIN='/usr/lib/enigma2/python/Plugins/Extensions/AddOnManager'
DreamElite1='/usr/lib/enigma2/python/DE'
DreamElite2='/usr/lib/enigma2/python/Plugins/DreamElite'
TDW='/usr/lib/enigma2/python/Plugins/Extensions/TDW'
NEWNIGMA2='/usr/lib/enigma2/python/Plugins/newnigma2'
SysCC='/usr/lib/enigma2/python/Plugins/Extensions/SysCC/plugin.pyo'
SATLODGE='/usr/lib/enigma2/python/Plugins/SatLodge'
PETERPAN='/usr/ppteam'
DreamOSat='/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatcamManager'
Demoni='/usr/lib/enigma2/python/Plugins/Extensions/Blue_Panel'
EmulatorManager='/usr/lib/enigma2/python/Plugins/Extensions/EmulatorManager'
#### checking your device and bin file #####
uname -m > $CHECK
sleep 1;
if grep -qs -i 'armv7l' cat $CHECK ; then
   echo ':Your Device IS ARM processor ...'
   if [ ! -f $ARMBIN ] ; then
         echo "**************************"
         echo "**** Bin file Missing ****"
         echo "**************************"
         rm -r $TMPDIR > /dev/null 2>&1
         rm -r $CHECK > /dev/null 2>&1
         exit 1
   else
         cp -f $ARMBIN $TMPDIR
   fi
elif grep -qs -i 'aarch64' cat $CHECK ; then
   echo ':Your Device IS AARCH64 processor ...'
   if [ ! -f $AARCH64BIN ] ; then
         echo "**************************"
         echo "**** Bin file Missing ****"
         echo "**************************"
         rm -r $TMPDIR > /dev/null 2>&1
         rm -r $CHECK > /dev/null 2>&1
         exit 1
   else
         cp -f $AARCH64BIN $TMPDIR
   fi
elif grep -qs -i 'mips' cat $CHECK ; then
   echo ':Your Device IS MIPS processor ...'
   if [ ! -f $MIPSBIN ] ; then
         echo "**************************"
         echo "**** Bin file Missing ****"
         echo "**************************"
         rm -r $TMPDIR > /dev/null 2>&1
         rm -r $CHECK > /dev/null 2>&1
         exit 1
   else
         cp -f $MIPSBIN $TMPDIR
   fi
else
   echo 'Sorry, your Device does not have the proper Emu'
   rm -r $TMPDIR > /dev/null 2>&1
   rm -r $CHECK > /dev/null 2>&1
   exit 1
fi
#########
if [ -r $DreamOSat ]; then
   echo "DreamOSat camManager"
   cp -rf $TMPDIR/DreamOSat/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
elif [ -e $GP3 ]; then
   echo "GP3 image"
   cp -rf $TMPDIR/GP3/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -f $GP4 ]; then
   echo "GP4 image"
   cp -rf $TMPDIR/GP4/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
else
if grep -qs -i "Power-Sat" /etc/issue; then
   echo "PowerSat image"
   cp -rf $TMPDIR/PowerSat/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif grep -qs -i "OoZooN" /etc/issue.net; then
   echo "OoZooN image"
   if [ ! -r /usr/camd ]; then
        mkdir -p /usr/camd > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/oozoon/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/camd/ > /dev/null 2>&1
elif [ -r $PETERPAN ]; then
   echo "PeterPan image"
   cp -rf $TMPDIR/PeterPan/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
   echo "0*ncam_cam.pp* Ncam *" >>/usr/ppteam/.emulist
elif [ -r $VTI ]; then
   echo "VTI image"
   cp -rf $TMPDIR/vti/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $TSIMAGE ]; then
   echo "OpenTS/Ts image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/ts/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -r $NEWNIGMA2 ]; then
   echo "newnigma2 image"
   cp -rf $TMPDIR/newnigma2/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $MERLIN ]; then
   echo "Merlin4 image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/Merlin4/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -d $DreamElite1 ]; then
   echo "Dream-Elite image"
   if [ ! -d /var/bin ]; then
      ln -sfn /usr/bin /var/bin
   fi
   cp -rf $TMPDIR/dreamelite/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
   touch /etc/DExtra
   chmod -R 755 /etc/DExtra
elif [ -d $DreamElite2 ]; then
   echo "Dream-Elite image"
   if [ ! -e /etc/enigma2/EliteSoftcam/ ]; then
      /bin/mkdir -p /etc/enigma2/EliteSoftcam 2> /dev/null
   fi
   if [ ! -e /usr/keys/ ]; then
      /bin/mkdir -p /usr/keys 2> /dev/null
   fi
   if [ ! -e /var/bin/ ]; then
      ln -s /usr/bin/ /var/bin 2> /dev/null
   fi
   if [ ! -e /var/etc/ ]; then
      ln -s /etc/ /var/etc 2> /dev/null
   fi
   if [ ! -e /var/keys/ ]; then
      ln -s /usr/keys/ /var/keys 2> /dev/null
   fi
   if [ ! -e /var/tuxbox/ ]; then
      ln -s /etc/tuxbox/ /var/tuxbox 2> /dev/null
   fi
   cp -rf $TMPDIR/dreamelite2/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $TDW ]; then
   echo "TDW image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/TDW/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -r $SATLODGE ]; then
   echo " Satlodge image"
   cp -rf $TMPDIR/satlodge/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $Demoni ]; then
   echo "DMS-Demoni image"
   cp -rf $TMPDIR/dddemon/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
elif [ -r $EmulatorManager ]; then
   echo "EmulatorManager image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/EmulatorManager/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -f $SysCC ]; then
   echo " SysCC Plugin"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/SysCC/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
else
echo "***************************************************"
echo "*                                                 *"
echo "* No emu script to this image now .. ask about it *"
echo "*                                                 *"
echo "***************************************************"
exit 1
fi
fi
######### checking config files #########
if [ ! -d $CONFIGPATH ]; then
   mkdir -p $CONFIGPATH > /dev/null 2>&1
fi
#if [ -f $CONFIGccache -a -f $CONFIGconf -a -f $CONFIGdvbapi -a -f $CONFIGprovid -a -f $CONFIGserver -a -f $CONFIGservices -a -f $CONFIGsrvid2 -a -f $CONFIGuser -a -f $AUTOROLL -a -f $SOFTCAM -a -f $CONSTANT -a -f $CCCAMCFG -a -f $NCAMFS ]; then
if [ -f $CONFIGserver -a -f $AUTOROLL -a -f $SOFTCAM -a -f $CONSTANT -a -f $CCCAMCFG ]; then
   echo "[ All Config Files found ]"
else
   echo "[ Some Config Files Missing .. will send it ]"
   echo "-r0"
#   if [ ! -f $CONFIGccache ]; then
#      cp -f $CONFIGccachetmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.ccache) file]"
#   fi
#   if [ ! -f $CONFIGconf ]; then
#      cp -f $CONFIGconftmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.conf) file]"
#   fi
#   if [ ! -f $CONFIGdvbapi ]; then
#      cp -f $CONFIGdvbapitmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.dvbapi) file]"
#   fi
#   if [ ! -f $CONFIGprovid ]; then
#      cp -f $CONFIGprovidtmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.provid) file]"
#   fi
   if [ ! -f $CONFIGserver ]; then
      cp -f $CONFIGservertmp $CONFIGPATH > /dev/null 2>&1
      echo "[ send (ncam.server) file]"
   fi
#   if [ ! -f $CONFIGservices ]; then
#      cp -f $CONFIGservicestmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.services) file]"
#   fi
#   if [ ! -f $CONFIGsrvid2 ]; then
#      cp -f $CONFIGsrvid2tmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.srvid2) file]"
#   fi
#   if [ ! -f $CONFIGuser ]; then
#      cp -f $CONFIGusertmp $CONFIGPATH > /dev/null 2>&1
#      echo "[ send (ncam.user) file]"
#   fi
   if [ ! -f $AUTOROLL ]; then
      cp -f $AUTOROLLtmp $AUTOROLL > /dev/null 2>&1
      echo "[ send (AutoRoll.Key) file]"
   fi
   if [ ! -f $SOFTCAM ]; then
      cp -f $SOFTCAMtmp $SOFTCAM > /dev/null 2>&1
      echo "[ send (SoftCam.Key) file]"
   fi
   if [ ! -f $CONSTANT ]; then
      cp -f $CONSTANTtmp $CONSTANT > /dev/null 2>&1
      echo "[ send (constant.cw) file]"
   fi
   if [ ! -f $CCCAMCFG ]; then
      cp -f $CONFIGCCCamCFGtmp $CCCAMCFG > /dev/null 2>&1
      echo "[ send (CCcam.cfg) file]"
   fi
#   if [ ! -f $NCAMFS ]; then
#      cp -f $NCAMFStmp $NCAMFS > /dev/null 2>&1
#      echo "[ send (ncam.fs) file]"
#   fi
   echo "-r0"
fi
   rm -f $CONFIGcookies > /dev/null 2>&1
   rm -f $CONFIGccache > /dev/null 2>&1
   rm -f $CONFIGconf > /dev/null 2>&1
   rm -f $CONFIGuser > /dev/null 2>&1
   rm -f $CONFIGdvbapi > /dev/null 2>&1
   rm -f $CONFIGprovid > /dev/null 2>&1
   rm -f $CONFIGservices > /dev/null 2>&1
   rm -f $CONFIGsrvid2 > /dev/null 2>&1
   rm -f $NCAMFS > /dev/null 2>&1
   cp -f $CONFIGcookiestmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGccachetmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGconftmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGusertmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGdvbapitmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGprovidtmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGservicestmp $CONFIGPATH > /dev/null 2>&1
   cp -f $CONFIGsrvid2tmp $CONFIGPATH > /dev/null 2>&1
   cp -f $NCAMFStmp $NCAMFS > /dev/null 2>&1

exit 0
