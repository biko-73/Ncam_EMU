#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
# Type: Ncam

/usr/script/ncam_cs.sh stop
sleep 5

rm -rf /usr/bin/Nncam
rm -rf /usr/script/ncam_cs.sh
rm -rf /usr/uninstall/ncam_remove.sh
rm -rf /lib/systemd/system/ncam.service
rm -rf /lib/systemd/system/ncam.socket

exit 0

